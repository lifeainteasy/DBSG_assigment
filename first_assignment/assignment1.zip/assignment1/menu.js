alert('반갑습니다. 최선을 다해 과제 수행 부탁드립니다^^*');

function gotoMenu() {
  document.querySelector(".navigation__checkbox").checked = false;
}
